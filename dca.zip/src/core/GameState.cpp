#include "GameState.hpp"

GameState::GameState() : state_machine(nullptr){}